#include <iostream>
#include "Polynomial.h"

int main() {
    return 0;
}