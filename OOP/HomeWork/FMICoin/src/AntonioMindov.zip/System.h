#ifndef FMICOIN_SYSTEM_H
#define FMICOIN_SYSTEM_H


void initializeDatabase();
void launchProgram();
void printWallets();


#endif //FMICOIN_SYSTEM_H
