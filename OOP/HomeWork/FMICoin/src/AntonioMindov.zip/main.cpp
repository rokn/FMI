#include "System.h"
#include <iostream>
using namespace std;

int main() {
    initializeDatabase();
    launchProgram();
    return 0;
}
